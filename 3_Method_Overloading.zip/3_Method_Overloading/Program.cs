﻿namespace _3_Method_Overloading
{
    public class Vehicle
    {
        public void Drive(int value)
        {
            Console.WriteLine($"Vehicle is moving at {value}kmph");
        }
        public void Drive(string value)
        {
            Console.WriteLine($"Vehicle is of {value} Brand");
        }
    }
    class Program
    {
        public static void Main()
        {
            Vehicle vehicle = new Vehicle();
            vehicle.Drive(250);
            vehicle.Drive("McLaren");
        }
    }
}
