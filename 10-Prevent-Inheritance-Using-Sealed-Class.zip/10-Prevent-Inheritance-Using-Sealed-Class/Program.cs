﻿namespace _10_Prevent_Inheritance_Using_Sealed_Class
{
    sealed class SecuritySystem
    {
        public void AuthenticateUser()
        {
            Console.Write("User Authenticated");
        }
    }
    class AdditionalSecurity : SecuritySystem
    {
        public void AdditionalCheck()
        {
            Console.Write("Additional Check Done");
        }
    }
    public class Program
    {
        public static void Main()
        {
            AdditionalSecurity additionalSecurity = new AdditionalSecurity();
            additionalSecurity.AuthenticateUser();
            additionalSecurity.AdditionalCheck();
        }
    }
}
