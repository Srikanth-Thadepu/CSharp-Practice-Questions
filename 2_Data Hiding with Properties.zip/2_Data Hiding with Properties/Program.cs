﻿namespace _2_Data_Hiding_with_Properties
{
    using System;

    class Student
    {
        private string name;
        private int rollNo;

        public string Name
        {
            get { return name; }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    Console.WriteLine("Name cannot be empty");
                }
                else
                {
                    name = value;
                }
            }
        }

        public int RollNo
        {
            get { return rollNo; }
            set
            {
                if (value < 0)
                {
                    Console.WriteLine("RollNo cannot be negative");
                }
                else
                {
                    rollNo = value;
                }
            }
        }

        public Student(string name, int rollNo)
        {
            Name = name;
            RollNo = rollNo;
        }

        public void display()
        {
            Console.WriteLine($"Name : {name}, RollNo: {rollNo}");
        }
    }

    class Program
    {
        static void Main()
        {
            Student student1 = new Student("John", 101);
            student1.display();
            Student student2 = new Student("Jane", -101);
            student2.display();
        }
    }
}
