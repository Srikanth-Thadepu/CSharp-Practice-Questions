﻿namespace _5_Interface_Abstract
{
    public interface IVehicle
    {
        public void Drive();
    }
    public class ICar : IVehicle
    {
        public void Drive()
        {
            Console.WriteLine("Car is moving");
        }
    }
    public class IBike : IVehicle
    {
        public void Drive()
        {
            Console.WriteLine("Bike is moving");
        }
    }
    public abstract class Vehicle
    {
        public abstract void Drive();
    }
    public class Car : Vehicle
    {
        public override void Drive()
        {
            Console.WriteLine("Car is moving");
        }
    }
    public class Bike : Vehicle
    {
        public override void Drive()
        {
            Console.WriteLine("Bike is moving");
        }
    }
    class Program
    {
        public static void Main()
        {
            IVehicle ivehicle1 = new ICar();
            ivehicle1.Drive();
            IVehicle ivehicle2 = new IBike();
            ivehicle2.Drive();
            Vehicle vehicle1 = new Car();
            vehicle1.Drive();
            Vehicle vehicle2 = new Bike();
            vehicle2.Drive();
        }
    }
}