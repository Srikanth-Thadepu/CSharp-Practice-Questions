﻿namespace _3_Constructor_Chaining_in_Inheritance
{
    public class Employee
    {
        public string Name{ get; set; }
        public int Salary { get; set; }
        public Employee(string name, int salary)
        {
            Name = name;
            Salary = salary;
        }
        public void GetDetails()
        {
            Console.WriteLine($"Name: {Name} and Salary: {Salary}");
        }

    }
    public class Manager : Employee
    {
        public int Bonus { get; set; }
        public Manager(string name, int salary, int bonus):base(name,salary)
        {
            Bonus = bonus;
        }
        public void GetDetails()
        {
            Console.WriteLine($"Name: {Name} and Salary: {Salary} and Bonus: {Bonus}");
        }
    }
    class Program
    {
        public static void Main()
        {
            Employee emp = new Employee("John", 10000);
            Manager mgr = new Manager("Smith", 20000, 5000);
            emp.GetDetails();
            mgr.GetDetails();

        }
    }
}
