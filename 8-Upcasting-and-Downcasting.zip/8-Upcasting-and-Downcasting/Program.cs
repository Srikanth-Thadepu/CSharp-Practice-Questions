﻿namespace _8_Upcasting_and_Downcasting
{
    public class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public Person(string name, int age)
        {
            Name = name;
            Age = age;
        }
        public virtual void GetDetails()
        {
            Console.WriteLine($"Name: {Name}, Age: {Age}");
        }
    }
    public class Student: Person
    {
        public int Rollno { get; set; }
        public Student(string name,int age,int rollno): base(name, age)
        {
            Rollno = rollno;
        }
        public override void GetDetails()
        {
            Console.WriteLine($"Name: {Name}, Age: {Age}, Rollno: {Rollno}");
        }
    }
    public class Program
    {
        public static void Main()
        {
            Student student1 = new Student("John", 20, 101);
            student1.GetDetails();

            Person person1 = student1; 
            person1.GetDetails();
;
            if (person1 is Student student)
            {
                student.GetDetails();
            }
            else
            {
                Console.WriteLine("person2 is not a student");
            }
        }
    }
}
