﻿namespace _6_Using_Virtual_Methods_in_Inheritance
{
    using System;
    class Person
    {
        public string name { get; set; }
        public int age { get; set; }
        public virtual void GetDetails()
        {
            Console.WriteLine($"Name: {name},Age: {age}");
        }
    }
    class Student : Person
    {
        public int rollNo { get; set; }
        public override void GetDetails() 
        {
            Console.WriteLine($"Student Name: {name} Age: {age} RollNo: {rollNo}");  
        }
    }
    class Teacher : Person
    {
        public string subject { get; set; }
        public override void GetDetails()
        {
            Console.WriteLine($"Teacher name: {name} Age: {age} Subject: {subject}");
        }
    }
    class Program
    {
        public static void Main()
        {
            Person student1 = new Student { name = "Srikanth", age = 21, rollNo = 7 };
            Person student2 = new Student { name="shasha",age=20,rollNo=5};
            Person teacher = new Teacher { name = "Subani", age = 68, subject = "English" };
            student1.GetDetails();
            student2.GetDetails();
            teacher.GetDetails();
        }
    }
}
