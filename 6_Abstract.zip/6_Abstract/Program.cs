﻿namespace _6_Abstract
{
    public abstract class Vehicle
    {
        public abstract void Drive();
    }
    public class Car : Vehicle
    {
        public override void Drive()
        {
            Console.WriteLine("Car is moving");
        }
    }
    public class Bike : Vehicle
    {
        public override void Drive()
        {
            Console.WriteLine("Bike is moving");
        }
    }
    class Program
    {
        public static void Main()
        {
            Vehicle vehicle1 = new Car();
            vehicle1.Drive();
            Vehicle vehicle2 = new Bike();
            vehicle2.Drive();
        }
    }
}
