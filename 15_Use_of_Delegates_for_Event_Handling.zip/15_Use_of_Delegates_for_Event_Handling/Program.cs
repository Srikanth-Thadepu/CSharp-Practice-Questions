﻿namespace _16_Factory_Pattern_for_Object_Creation
{
    interface Vehicle
    {
        void Name();
    }
    public class Car:Vehicle
    {
        public void Name()
        {
            Console.WriteLine("It is a Car");
        }
    }
    public class Bike : Vehicle
    {
        public void Name()
        {
            Console.WriteLine("It is a Bike");
        }
    }
    class VehicleFactory
    {
        public Vehicle GetVehicle(string VehicleType)
        {
            switch(VehicleType.ToLower())
            {
                case "car":
                    return new Car();
                case "bike":
                    return new Bike();
                default:
                    throw new Exception("Invalid Vehicle");
            }
        }
    }
    class Program
    {
        public static void Main()
        {
            VehicleFactory vehicleFactory = new VehicleFactory();
            Vehicle vehicle = vehicleFactory.GetVehicle("Car");
            Vehicle vehicle2=vehicleFactory.GetVehicle("bIke");
        }
    }
}
