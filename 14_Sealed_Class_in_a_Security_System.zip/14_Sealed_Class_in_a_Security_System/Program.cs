﻿namespace _14_Sealed_Class_in_a_Security_System
{
    sealed class SecuritySystem
    {
        public void Authentication()
        {
            Console.WriteLine("Authentication is done");
        }
    }
    class AdvancedSystem : SecuritySystem
    {
        public void Encryption()
        {
            Console.WriteLine("Encryption is done");
        }
    }
    class Program
    {
        public static void Main()
        {
            SecuritySystem sys=new AdvancedSystem();
            sys.Authentication();
        }
    }
}
