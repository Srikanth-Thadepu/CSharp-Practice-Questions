﻿namespace _2_Method_Overriding_and_Base_Keyword
{
    public class Vehicle
    {
        public string Brand { get; set; }
        public int Speed { get; set; }
        public virtual void DisplayInfo()
        {
            Console.WriteLine("Brand: " + Brand);
            Console.WriteLine("Speed: " + Speed);
        }
    }
    public class Car : Vehicle
    {
        public string FeulType { get; set; }
        public override void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine("Feul Type: " + FeulType);
        }
    }
    public class Bike : Vehicle
    {
        public string EngineType { get; set; }
        public override void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine("Engine Type: " + EngineType);
        }
    }

    class Program
    {
        public static void Main()
        {
            Car car = new Car();
            car.Brand = "McLaren";
            car.Speed= 350;
            car.FeulType = "Petrol";
            Console.WriteLine("**Car Details**");
            car.DisplayInfo();
            Bike bike = new Bike();
            bike.Brand = "KTM";
            bike.Speed = 250;
            bike.EngineType = "4 Stroke";
            Console.WriteLine("**Bike Details**");
            bike.DisplayInfo();
        }
    }

}