﻿namespace _1_Polymorphism_RealWorld_Example
{
    public class Vehicle
    {
        public virtual void Drive()
        {
            Console.WriteLine("Vehicle is moving");
        }
    }
    public class Car : Vehicle
    {
        public override void Drive()
        {
            Console.WriteLine("Car is moving");
        }
    }
    class Program
    {
        public static void Main()
        {
            Vehicle vehicle1 = new Vehicle();
            Vehicle vehicle2 = new Car();
            vehicle1.Drive();
            vehicle2.Drive();

        }
    }

}
