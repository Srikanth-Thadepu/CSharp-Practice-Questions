﻿namespace _7_Virtual
{
    public class Vehicle
    {
        public void Drive()
        {
            Console.WriteLine("Vehicle is moving");
        }
    }
    public class Car : Vehicle
    {
        public void Drive()
        {
            Console.WriteLine("Car is moving");
        }
    }
    public class Program
    {
        public static void Main()
        {
            Vehicle vehicle=new Vehicle();
            vehicle.Drive();
            Vehicle car = new Car();//it is not overriding the method of base class, it is hiding it
            car.Drive();
        }
    }
}
