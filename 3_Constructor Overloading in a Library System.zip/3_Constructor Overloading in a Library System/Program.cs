﻿namespace _3_Constructor_Overloading_in_a_Library_System
{
    using System;

    class Book
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public string ISBN { get; set; }

        public Book()
        {
            Title = "Unknown Title";
            Author = "Unknown Author";
            ISBN = "000-0000000000";
        }

        public Book(string title, string author)
        {
            Title = title;
            Author = author;
            ISBN = "Not Assigned";
        }
        public Book(string title, string author, string isbn)
        {
            Title = title;
            Author = author;
            ISBN = isbn;
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"Title: {Title}, Author: {Author}, ISBN: {ISBN}");
        }
    }

    class Program
    {
        static void Main()
        {
            Book book1 = new Book();
            book1.DisplayInfo();

            Book book2 = new Book("The Great Gatsby", "F. Scott Fitzgerald");
            book2.DisplayInfo();

            Book book3 = new Book("1984", "George Orwell", "978-0451524935");
            book3.DisplayInfo();
        }
    }

}
