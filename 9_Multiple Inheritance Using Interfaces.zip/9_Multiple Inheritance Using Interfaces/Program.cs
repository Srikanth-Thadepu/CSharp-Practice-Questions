﻿namespace _9_Multiple_Inheritance_Using_Interfaces
{
    using System;
    public interface IPrintable
    {
        void print();
    }
    public interface ISerializeable
    {
        void serialize();
    }
    public class Report : IPrintable , ISerializeable
    {
        public void print()
        {
            Console.WriteLine("Printing Report");
        }
        public void serialize()
        {
            Console.WriteLine("Serializing Report");
        }
    }
    public class  Program
    {
        public static void Main()
        {
            Report report = new Report();
            report.print();
            report.serialize();
        }
    }
}
