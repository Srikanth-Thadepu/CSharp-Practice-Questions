﻿namespace _1_Implement_a_Basic_Inheritance_Hierarchy
{
    public class Vehicle
    {
        public string Brand { get; set; }
        public int Speed { get; set; }

        public void Display_info()
        {
            Console.WriteLine($"Brand: {Brand}, Speed: {Speed}");
        }
    }
    public class Car : Vehicle
    {
        public void Display_info()
        {
            Console.WriteLine($"This is a {Brand} brand car and its maximun speed is {Speed}kmph");
        }
    }
    public class Bike : Vehicle
    {
        public void Display_info()
        {
            Console.WriteLine($"This is a {Brand} brand bike and its maximun speed is {Speed}kmph");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Car car = new Car();
            car.Brand = "Ferrari";
            car.Speed = 300;
            car.Display_info();
            Bike bike = new Bike();
            bike.Brand = "KTM";
            bike.Speed = 250;
            bike.Display_info();
        }
    }

}
