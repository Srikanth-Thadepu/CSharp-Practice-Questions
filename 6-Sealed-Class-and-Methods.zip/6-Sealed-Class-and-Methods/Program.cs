﻿namespace _6_Sealed_Class_and_Methods
{
    public class Account
    {
        public virtual void CalculateInterest()
        {
            Console.WriteLine("Calculating the interest");
        }
    }
    public class SavingsAccount : Account
    {
        public sealed override void CalculateInterest()
        {
            Console.WriteLine("Calculating the interest for savings account");
        }
    }

    class Program
    {
        public static void Main()
        {
            Account account = new Account();
            account.CalculateInterest();
            SavingsAccount savings=new SavingsAccount();
            savings.CalculateInterest();
        }
    }
}
