﻿namespace _4_MethodOverriding
{
    public class Vehicle
    {
        public virtual void Drive()
        {
            Console.WriteLine("Vehicle is moving");
        }
    }
    public class Car : Vehicle
    {
        public override void Drive()
        {
            Console.WriteLine("Car is moving");
        }
    }
    public class Bike : Vehicle 
    {
        public new void Drive()
    {
        Console.WriteLine("Bike is moving");
    }
    }
    class Program
    {
        public static void Main()
        {
            Vehicle vehicle1=new Vehicle();
            vehicle1.Drive();
            Vehicle vehicle2 = new Car();
            vehicle2.Drive();
            Vehicle vehicle3 = new Bike();
            vehicle3.Drive();
        }
    }
}
