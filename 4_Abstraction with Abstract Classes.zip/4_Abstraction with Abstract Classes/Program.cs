﻿namespace _4_Abstraction_with_Abstract_Classes
{
    using System;

    abstract class Shape
    {
        public abstract double CalculateArea();
    }

    class Circle : Shape
    {
        private double radius;

        public Circle(double radius)
        {
            this.radius = radius;
        }

        public override double CalculateArea()
        {
            return Math.PI * radius * radius;
        }
    }

    class Rectangle : Shape
    {
        private double width, height;

        public Rectangle(double width, double height)
        {
            this.width = width;
            this.height = height;
        }

        public override double CalculateArea()
        {
            return width * height;
        }
    }

    class Program
    {
        static void Main()
        {
            Shape myCircle = new Circle(5);
            Console.WriteLine($"Circle Area: {myCircle.CalculateArea()}");

            Shape myRectangle = new Rectangle(4, 6);
            Console.WriteLine($"Rectangle Area: {myRectangle.CalculateArea()}");
        }
    }

}
