﻿namespace _7_Multiple_Inheritance_Using_Interfaces
{
    public interface IFlyable
    {
        void Fly()
        {
            Console.WriteLine("I can fly..");
        }
    }

    public interface ISwimmable
    {
        void Swim()
        {
            Console.WriteLine("I can swim..");
        }
    }

    public class Duck:IFlyable, ISwimmable
    {
        public void Fly()
        {
            Console.WriteLine("Duck can fly..");
        }
        public void Swim()
        {
            Console.WriteLine("Duck can swim..");
        }
    }
    class Program
    {
        static void Main()
        {
            Duck duck = new Duck();
            duck.Fly();
            duck.Swim();
        }
    }
}
