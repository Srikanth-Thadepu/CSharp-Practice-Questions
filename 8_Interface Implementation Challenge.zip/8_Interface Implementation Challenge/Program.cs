﻿namespace _8_Interface_Implementation_Challenge
{
    using System;
    public interface IPlayable
    {
        void Play();
    }
    public class MusicPlayer : IPlayable
    {
        public void Play()
        {
            Console.WriteLine("I play music");
        }
    }
    public class  VideoPlayer : IPlayable
    {
        public void Play()
        {
            Console.WriteLine("I play video");
        }
    }

    class Program
    {
        static void Main()
        { 
            IPlayable playable1 = new MusicPlayer();
            playable1.Play();
            IPlayable playable2 = new VideoPlayer();
            playable2.Play();
        }
    }
}
