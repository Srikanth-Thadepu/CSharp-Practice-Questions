﻿namespace _5_Interface_vs_Inheritance_in_C_
{
    public interface IMovable
    {
        public void Move();
    }
    public class Machine
    {
        public void Start()
        {
            Console.WriteLine("Machine is starting");
        }
    }
    public class Robot : Machine, IMovable
    {
        public void Move()
        {
            Console.WriteLine("Robot is moving");
        }
    }
    public class Program
    {
        public static void Main()
        {
            Robot robot = new Robot();
            robot.Start();
            robot.Move();
        }
    }
}
