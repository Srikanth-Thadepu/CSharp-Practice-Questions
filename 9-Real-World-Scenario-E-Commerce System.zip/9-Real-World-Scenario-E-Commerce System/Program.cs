﻿namespace _9_Real_World_Scenario_E_Commerce_System
{
    public class Product
    {
        public string Name { get; set; }
        public int Price { get; set; }
        public Product(string name, int price)
        {
            Name = name;
            Price = price;
        }
        public virtual double GetDiscountedPrice()
        {
            return Price;
        }
    }
    public class ElectronicProduct : Product
    {
        public double Discount { get; set; }
        public ElectronicProduct(string name, int price, double discount) : base(name, price)
        {
            Discount = discount;
        }
        public override double GetDiscountedPrice()
        {
            return Price-(Price*Discount / 100);
        }
    }
    public class ClothingProduct : Product
    {
        public double Discount { get; set; }
        public ClothingProduct(string name, int price, double discount) : base(name, price)
        {
            Discount = discount;
        }
        public override double GetDiscountedPrice()
        {
            return Price - (Price * Discount / 100);
        }
    }
    public class Program
    {
        public static void Main()
        {
            Product product1 = new ElectronicProduct("Laptop", 50000, 10);
            Console.WriteLine("Product 1: " + product1.GetDiscountedPrice());
            Product product2 = new ClothingProduct("Shirt", 1000, 20);
            Console.WriteLine("Product 2: " + product2.GetDiscountedPrice());
        }
    }
}
