﻿namespace _1_Encapsulation_Challenge
{
    class BankAccount
    {
        private decimal bankBalance;

        public BankAccount(decimal initialAmount)
        {
            if (initialAmount > 0)
            {
                bankBalance = initialAmount;
            }
            else
            {
                Console.WriteLine("Amount cannot be negative\n");
                bankBalance = 0;
            }
        }
        public void deposit(decimal amount)
        {
            bankBalance = bankBalance + amount;
            Console.Write($"Your account is successfully credited with Rs. {amount}." +
                $"Current balance is {bankBalance}\n");
        }

        public void withdraw(decimal amount)
        {
            if (amount > bankBalance)
            {
                Console.WriteLine("Insufficient balance\n");
            }
            else
            {
                bankBalance = bankBalance - amount;
                Console.WriteLine($"Your account is debited with Rs. {amount}." +
                    $"Current balance is {bankBalance} \n");
            }

        }

        public void checkBalnce()
        {
            Console.WriteLine($"Your current balance is {bankBalance}\n");
        }
    }

    class Program()
    {
        public static void Main()
        {
            BankAccount myAccount = new BankAccount(2000);
            myAccount.deposit(1000);
            myAccount.withdraw(3500);
            myAccount.withdraw(500);
            myAccount.checkBalnce();
        }
    }
}
