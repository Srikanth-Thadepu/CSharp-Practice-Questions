﻿namespace _9_Output
{
    public class Animal
    {
        public virtual void Speak()
        {
            Console.WriteLine("Animal speaks");
        }
    }
    public class Dog : Animal
    {
        public override void Speak()
        {
            Console.WriteLine("Dog barks");
        }
    }
    class Program
    {
        public static void Main()
        {
            Animal a = new Dog();
            a.Speak();
        }
    }
}
