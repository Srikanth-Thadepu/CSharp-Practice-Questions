﻿namespace _13_Static_Members_in_a_Banking_System
{
    public class Bank
    {
        public static double InterestRate { get; set; }
        public static void SetInterestRate(double interestRate)
        {
            InterestRate = interestRate;
        }
    }

    class Program
    {
        public static void Main()
        {
            Bank bank1 = new Bank();
            Bank bank2 = new Bank();
            Bank.SetInterestRate(1.5);
            Console.WriteLine($"Bank1 has interest rate of {Bank.InterestRate}");
            Console.WriteLine($"Bank2 has interest rate of {Bank.InterestRate}\n");
            Bank.SetInterestRate(2.5);
            Console.WriteLine($"Bank1 has interest rate of {Bank.InterestRate}");
            Console.WriteLine($"Bank2 has interest rate of {Bank.InterestRate}");
        }
    }
}
