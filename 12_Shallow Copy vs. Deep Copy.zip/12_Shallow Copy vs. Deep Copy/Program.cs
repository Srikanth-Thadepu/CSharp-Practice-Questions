﻿using System;

public class Manager
{
    public string Name { get; set; }

    public Manager(string name)
    {
        Name = name;
    }

    public override string ToString()
    {
        return $"Manager(Name={Name})";
    }
}

public class Department : ICloneable
{
    public string Name { get; set; }
    public Manager Manager { get; set; }

    public Department(string name, Manager manager)
    {
        Name = name;
        Manager = manager;
    }

    public object Clone()
    {
        return this.MemberwiseClone();
    }

    public Department DeepCopy()
    {
        return new Department(this.Name, new Manager(this.Manager.Name));
    }

    public override string ToString()
    {
        return $"Department(Name={Name}, Manager={Manager})";
    }
}

class Program
{
    static void Main()
    {
        Manager manager1 = new Manager("Alice");
        Department department1 = new Department("HR", manager1);

        Department departmentShallow = (Department)department1.Clone();
        Department departmentDeep = department1.DeepCopy();

        manager1.Name = "Bob";

        Console.WriteLine("Original Department: " + department1);
        Console.WriteLine("Shallow Copy Department: " + departmentShallow);
        Console.WriteLine("Deep Copy Department: " + departmentDeep);
    }
}
