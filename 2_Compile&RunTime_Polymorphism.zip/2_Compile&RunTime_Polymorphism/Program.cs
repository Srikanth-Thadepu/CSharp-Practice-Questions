﻿namespace _2_Compile_RunTime_Polymorphism
{
    public class Vehicle
    {
        public virtual void Drive(int value)
        {
            Console.WriteLine($"Vehicle is moving at {value}kmph");
        }
        public void Drive(string value)
        {
            Console.WriteLine($"Vehicle is of {value} Brand");
        }
    }
    public class Car : Vehicle
    {
        public override void Drive(int value)
        {
            Console.WriteLine($"Car is moving at {value}kmph");
        }
    }
    class Program
    {
        public static void Main()
        {
            Vehicle vehicle1 = new Vehicle();
            vehicle1.Drive(250);
            vehicle1.Drive("McLaren");
            Vehicle vehicle2=new Car();
            vehicle2.Drive(250);
        }
    }

}
