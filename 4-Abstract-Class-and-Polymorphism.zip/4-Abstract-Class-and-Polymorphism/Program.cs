﻿namespace _4_Abstract_Class_and_Polymorphism
{
    public abstract class Animal
    {
        public abstract void MakeSound();
    }
    public class Dog:Animal
    {
        public override void MakeSound()
        {
            Console.WriteLine("Wooff..Woof..");
        }
    }
    public class Cat : Animal
    {
        public override void MakeSound()
        {
            Console.WriteLine("Meow..Meow..");
        }
    }
    class Program
    {
        public static void Main()
        {
            Dog dog = new Dog();
            dog.MakeSound();
            Cat cat = new Cat();
            cat.MakeSound();
        }
    }
}
