﻿namespace _7_Method_Overloading_in_a_Calculator_Class
{
    using System;

    class Calculator
    {
        public int Add(int a, int b)
        {
            return a + b ;
        }
        public int Add(int a, int b, int c)
        {
            return a + b + c;
        }
        public double Add(double a, double b)
        {
            return a + b;
        }
    }
    class Program
    {
        public static void Main()
        {
            Calculator calulate = new Calculator();
            Console.WriteLine($"Sum of two integers is: {calulate.Add(12, 13)}");
            Console.WriteLine($"Sum of three integers is: {calulate.Add(11,12,13)}");
            Console.WriteLine($"Sum of two double integers is: {calulate.Add(12.3,11.3)}");
        }
    }


}
